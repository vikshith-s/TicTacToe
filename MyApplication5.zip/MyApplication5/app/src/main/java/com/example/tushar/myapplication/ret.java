package com.example.tushar.myapplication;

public class ret {
    public   static int flag=0;


}
